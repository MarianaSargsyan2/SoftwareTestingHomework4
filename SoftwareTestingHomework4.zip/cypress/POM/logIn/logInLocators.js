export const loginLocators = {
    phoneNumberField: 'input[name="username"]', 
    passwordField: 'input[name="password"]', 
    loginButton: 'input.login-btn', 
  };
  